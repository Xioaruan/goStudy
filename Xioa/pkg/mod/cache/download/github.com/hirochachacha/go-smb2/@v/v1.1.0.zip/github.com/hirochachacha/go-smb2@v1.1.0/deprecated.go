package smb2

type Client = Session          // deprecated type name
type RemoteFileSystem = Share  // deprecated type name
type RemoteFile = File         // deprecated type name
type RemoteFileStat = FileStat // deprecated type name

const MaxReadSizeLimit = 0x100000 // deprecated constant
